<?php
session_start();
$conn = mysqli_connect("localhost","root","","geekboz_db");
if(!$conn){ die("Database connection failed: ".mysqli_connect_error()); }

// Logout
if(isset($_GET['logout'])){
    session_destroy();
    header("Location: index.php");
    exit;
}

// Register
$register_msg = '';
if(isset($_POST['register'])){
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $phone = mysqli_real_escape_string($conn,$_POST['phone']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    $hash = md5($password); // For PHP 5.3 simplicity
    $check = mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($check) > 0){
        $register_msg = "Email already exists!";
    } else {
        mysqli_query($conn,"INSERT INTO users (name,email,phone,password) VALUES ('$name','$email','$phone','$hash')");
        $register_msg = "Account created! Please login.";
    }
}

// Login
$login_msg = '';
if(isset($_POST['login'])){
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    $hash = md5($password);
    $res = mysqli_query($conn,"SELECT * FROM users WHERE email='$email' AND password='$hash'");
    if(mysqli_num_rows($res)==1){
        $user = mysqli_fetch_assoc($res);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        header("Location: index.php");
        exit;
    } else {
        $login_msg = "Invalid credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>GeekBoz - Account</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<style>
body{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;padding:0;}
.container{width:400px;margin:50px auto;background:#fff;padding:30px;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);}
h2{text-align:center;margin-bottom:20px;}
form{margin-bottom:20px;}
input[type=text],input[type=email],input[type=password]{width:100%;padding:10px;margin:5px 0 15px;border-radius:5px;border:1px solid #ccc;}
button{padding:12px 20px;border:none;border-radius:5px;background:#e63946;color:#fff;cursor:pointer;}
button:hover{background:#d62828;}
.toggle-btn{background:#333;color:#fff;width:100%;margin-top:10px;}
.toggle-btn:hover{background:#555;}
.message{color:red;text-align:center;margin-bottom:15px;}
</style>
<script>
function toggleForms(){ 
    var login = document.getElementById('loginForm'); 
    var reg = document.getElementById('registerForm'); 
    if(login.style.display=='none'){ login.style.display='block'; reg.style.display='none'; } 
    else{ login.style.display='none'; reg.style.display='block'; }
}
</script>
</head>
<body>
<div class="container">
<h2>GeekBoz Account</h2>

<?php if($login_msg) echo '<div class="message">'.$login_msg.'</div>'; ?>
<form id="loginForm" method="post" <?php if(isset($_POST['register'])) echo 'style="display:none;"'; ?>>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit" name="login">Login</button>
<button type="button" class="toggle-btn" onclick="toggleForms()">Create Account</button>
</form>

<?php if($register_msg) echo '<div class="message">'.$register_msg.'</div>'; ?>
<form id="registerForm" method="post" <?php if(!isset($_POST['register'])) echo 'style="display:none;"'; ?>>
<input type="text" name="name" placeholder="Full Name" required>
<input type="email" name="email" placeholder="Email" required>
<input type="text" name="phone" placeholder="Phone">
<input type="password" name="password" placeholder="Password" required>
<button type="submit" name="register">Register</button>
<button type="button" class="toggle-btn" onclick="toggleForms()">Already Have Account</button>
</form>
</div>
</body>
</html>
