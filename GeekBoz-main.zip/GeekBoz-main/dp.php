<?php
$host = "localhost";
$dbname = "geekboz_db";
$user = "root"; // default WAMP username
$pass = "";     // default WAMP password

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "✅ Database connected successfully!";
} catch(PDOException $e) {
    die("❌ Database connection failed: " . $e->getMessage());
}
?>
