-- GeekBoz Database Schema (Old MySQL-Compatible Version)
-- Safe to run in older PHPMyAdmin / MySQL setups

CREATE DATABASE IF NOT EXISTS geekboz_db;
USE geekboz_db;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    password VARCHAR(255) NOT NULL,
    status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME NULL,
    updated_at DATETIME DEFAULT NULL
);

-- Categories table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    image VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    original_price DECIMAL(10,2),
    category_id INT NOT NULL,
    image VARCHAR(255),
    features TEXT,
    stock_quantity INT DEFAULT 0,
    featured BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'inactive', 'out_of_stock', 'deleted') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Cart table
CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_product (user_id, product_id)
);

-- Orders table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_number VARCHAR(20) UNIQUE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'confirmed', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    shipping_address TEXT,
    billing_address TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Order items table
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Admin users table
CREATE TABLE admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('super_admin', 'admin', 'moderator') DEFAULT 'admin',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME NULL
);

-- Insert default categories
INSERT INTO categories (name, slug, description) VALUES
('Gaming Laptops', 'gaming-laptops', 'High-performance gaming laptops'),
('Graphics Cards', 'graphics-cards', 'GPU cards for gaming and professional use'),
('Gaming Peripherals', 'gaming-peripherals', 'Mice, keyboards, headsets, and other gaming accessories'),
('Components', 'components', 'PC components like CPU, RAM, motherboard, etc.'),
('Custom PCs', 'custom-pcs', 'Pre-built and custom PC configurations');

-- Insert sample products (category_id matches above)
INSERT INTO products (name, description, price, original_price, category_id, image, features, stock_quantity, featured) VALUES
('ASUS ROG Strix G15', 'High-performance gaming laptop with RTX 4060', 89999.00, 99999.00, 1, 'https://images.unsplash.com/photo-1593640408182-31c70c8268f5', 'RTX 4060, 16GB RAM, 512GB SSD', 10, 1),
('Apple MacBook Pro 16"', 'Powerful laptop with M2 Pro chip for professionals', 239999.00, 249999.00, 1, 'https://images.unsplash.com/photo-1612831455542-0d152e5361e6', 'M2 Pro, 16GB RAM, 1TB SSD', 5, 1),
('RTX 4070 Graphics Card', 'Powerful GPU for 1440p gaming', 49999.00, 52999.00, 2, 'https://images.unsplash.com/photo-1652754271476-0b6cf297b827', '12GB GDDR6X, 2610MHz Boost Clock', 15, 1),
('Gaming Headset Pro X', 'Premium gaming headset with 7.1 surround', 6999.00, 8999.00, 3, 'https://images.unsplash.com/photo-1660391532247-4a8ad1060817', '7.1 Surround Sound, RGB Lighting', 25, 1),
('Gaming Mouse Elite', 'High-precision gaming mouse', 3499.00, 4999.00, 3, 'https://images.unsplash.com/photo-1628832307345-7404b47f1751', '16000 DPI, Ergonomic Design', 30, 0),
('Intel Core i7-13700K', 'High-performance CPU for gaming and productivity', 32999.00, 35999.00, 4, 'https://images.unsplash.com/photo-1555617981-dac3880eac6e', '16 cores, 24 threads, 3.4GHz base', 20, 0),
('Custom Gaming PC Build', 'Pre-built gaming PC with latest components', 129999.00, 149999.00, 5, 'https://images.unsplash.com/photo-1733945761533-727f49908d70', 'RTX 4070, i7-13700K, 32GB RAM', 5, 1);

-- Default admin user (password = admin123)
INSERT INTO admin_users (username, email, password, role) VALUES
('admin', 'admin@geekboz.in', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin');

-- Chat messages table
CREATE TABLE chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    sender_type ENUM('user', 'bot', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session_id (session_id),
    INDEX idx_created_at (created_at)
);

-- Indexes for performance
CREATE INDEX idx_products_category_id ON products(category_id);
CREATE INDEX idx_products_status ON products(status);
CREATE INDEX idx_products_featured ON products(featured);
CREATE INDEX idx_cart_user_id ON cart(user_id);
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_order_items_order_id ON order_items(order_id);
