<!DOCTYPE html>
<html>
<head>
<title>Support - GeekBoz</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;}
.container{width:600px;margin:50px auto;background:#fff;padding:30px;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);}
h2{text-align:center;}
textarea,input[type=text],input[type=email]{width:100%;padding:10px;margin:5px 0 15px;border-radius:5px;border:1px solid #ccc;}
button{padding:12px 20px;border:none;border-radius:5px;background:#e63946;color:#fff;cursor:pointer;}
button:hover{background:#d62828;}
</style>
</head>
<body>
<div class="container">
<h2>Contact Support</h2>
<form>
<input type="text" placeholder="Name" required>
<input type="email" placeholder="Email" required>
<textarea placeholder="Your message" rows="6" required></textarea>
<button type="submit">Send Message</button>
</form>
<p>Or reach us at: support@geekboz.in | +91 9876543210</p>
</div>
</body>
</html>
