<?php
session_start();
$conn = mysqli_connect("localhost","root","","geekboz_db");
if(!$conn){ die("DB failed: " . mysqli_connect_error()); }

// Redirect to cart if cart is empty
if(!isset($_SESSION['cart']) || empty($_SESSION['cart'])){
    header("Location: cart.php");
    exit;
}

// Calculate total
$cart_items = $_SESSION['cart'];
$total_amount = 0;
foreach($cart_items as $pid => $qty){
    $res = mysqli_query($conn,"SELECT price FROM products WHERE id=$pid");
    $prod = mysqli_fetch_assoc($res);
    $total_amount += $prod['price'] * $qty;
}

// Handle payment submission
$payment_status = '';
$order_id = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $payment_method = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);
    
    // Get user_id from session or create guest user
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1;
    
    // Generate order number
    $order_number = 'ORD' . time() . rand(100, 999);
    
    // Simulate payment processing
    $payment_success = false;
    $payment_error = '';
    
    if($payment_method === 'cod'){
        // COD always succeeds
        $payment_success = true;
    } elseif($payment_method === 'card'){
        // Simulate card validation
        $card_number = $_POST['card_number'];
        if(strlen($card_number) === 16 && is_numeric($card_number)){
            // 80% success rate for demo
            $payment_success = (rand(1, 100) <= 80);
            if(!$payment_success){
                $payment_error = "Card declined. Please try again.";
            }
        } else {
            $payment_error = "Invalid card number.";
        }
    } elseif($payment_method === 'upi'){
        // Simulate UPI validation
        $upi_id = $_POST['upi_id'];
        if(strpos($upi_id, '@') !== false && strlen($upi_id) >= 5){
            // 85% success rate for demo
            $payment_success = (rand(1, 100) <= 85);
            if(!$payment_success){
                $payment_error = "UPI transaction failed. Please try again.";
            }
        } else {
            $payment_error = "Invalid UPI ID format.";
        }
    } elseif($payment_method === 'wallet'){
        // Simulate wallet payment
        $payment_success = true;
    }
    
    if($payment_success){
        // Create order in database
        $shipping_address = "$address, $city - $pincode";
        $query = "INSERT INTO orders (user_id, order_number, total_amount, status, payment_method, payment_status, shipping_address) 
                  VALUES ($user_id, '$order_number', $total_amount, 'confirmed', '$payment_method', 'paid', '$shipping_address')";
        
        if(mysqli_query($conn, $query)){
            $order_db_id = mysqli_insert_id($conn);
            
            // Add order items
            foreach($cart_items as $pid => $qty){
                $res = mysqli_query($conn,"SELECT price FROM products WHERE id=$pid");
                $prod = mysqli_fetch_assoc($res);
                mysqli_query($conn,"INSERT INTO order_items (order_id, product_id, quantity, price) 
                                   VALUES ($order_db_id, $pid, $qty, ".$prod['price'].")");
            }
            
            // Clear cart
            unset($_SESSION['cart']);
            
            $payment_status = 'success';
            $order_id = $order_number;
        } else {
            $payment_error = "Database error. Please contact support.";
            $payment_status = 'error';
        }
    } else {
        $payment_status = 'failed';
    }
}

// Success page
if($payment_status === 'success'){
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmed - GeekBoz</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%); color: #fff; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
    .success-container { background: linear-gradient(145deg, #1e1e1e, #252525); border-radius: 20px; padding: 60px 40px; text-align: center; border: 2px solid #2ecc71; box-shadow: 0 20px 60px rgba(46, 204, 113, 0.3); max-width: 600px; animation: slideUp 0.6s ease; }
    @keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
    .success-icon { font-size: 80px; color: #2ecc71; margin-bottom: 20px; }
    .success-container h1 { font-size: 42px; margin-bottom: 15px; color: #2ecc71; }
    .success-container p { font-size: 18px; color: #aaa; margin-bottom: 10px; line-height: 1.6; }
    .order-number { background: rgba(46, 204, 113, 0.2); padding: 20px; border-radius: 10px; margin: 30px 0; border-left: 4px solid #2ecc71; }
    .order-number label { color: #aaa; font-size: 14px; display: block; margin-bottom: 8px; }
    .order-number .number { font-size: 28px; font-weight: bold; color: #2ecc71; font-family: monospace; }
    .btn { display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #e63946, #ff4757); color: #fff; text-decoration: none; border-radius: 10px; margin-top: 20px; transition: all 0.3s; border: none; cursor: pointer; font-size: 16px; font-weight: 600; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(230, 57, 70, 0.4); }
    .details { text-align: left; background: rgba(255,255,255,0.05); padding: 20px; border-radius: 10px; margin: 20px 0; }
    .detail-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.1); }
    .detail-row:last-child { border-bottom: none; }
    .detail-label { color: #aaa; }
    .detail-value { color: #2ecc71; font-weight: bold; }
    </style>
    </head>
    <body>
    <div class="success-container">
        <div class="success-icon"><i class="fas fa-check-circle"></i></div>
        <h1>Order Confirmed!</h1>
        <p>Your order has been successfully placed.</p>
        <div class="order-number">
            <label>Order Number</label>
            <div class="number"><?php echo $order_id; ?></div>
        </div>
        <div class="details">
            <div class="detail-row">
                <span class="detail-label">Amount Paid</span>
                <span class="detail-value">₹<?php echo number_format($total_amount, 2); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Payment Status</span>
                <span class="detail-value">Paid</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Delivery Status</span>
                <span class="detail-value">Processing</span>
            </div>
        </div>
        <p style="margin-top: 20px; font-size: 16px;">A confirmation email has been sent to your registered email address.</p>
        <a href="index.php" class="btn"><i class="fas fa-home"></i> Back to Home</a>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// Failed payment page
if($payment_status === 'failed'){
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed - GeekBoz</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%); color: #fff; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
    .error-container { background: linear-gradient(145deg, #1e1e1e, #252525); border-radius: 20px; padding: 60px 40px; text-align: center; border: 2px solid #e63946; box-shadow: 0 20px 60px rgba(230, 57, 70, 0.3); max-width: 600px; }
    .error-icon { font-size: 80px; color: #e63946; margin-bottom: 20px; }
    .error-container h1 { font-size: 42px; margin-bottom: 15px; color: #e63946; }
    .error-message { font-size: 18px; color: #aaa; margin: 20px 0; line-height: 1.6; }
    .btn { display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #e63946, #ff4757); color: #fff; text-decoration: none; border-radius: 10px; margin: 20px 10px; transition: all 0.3s; font-size: 16px; font-weight: 600; border: none; cursor: pointer; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(230, 57, 70, 0.4); }
    </style>
    </head>
    <body>
    <div class="error-container">
        <div class="error-icon"><i class="fas fa-times-circle"></i></div>
        <h1>Payment Failed</h1>
        <p class="error-message"><?php echo $payment_error ?: "Your payment could not be processed. Please try again."; ?></p>
        <div>
            <button onclick="window.history.back()" class="btn"><i class="fas fa-redo"></i> Try Again</button>
            <a href="cart.php" class="btn"><i class="fas fa-shopping-cart"></i> Back to Cart</a>
        </div>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// Checkout form page
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout - GeekBoz</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
    color: #fff;
    min-height: 100vh;
    padding: 20px 0;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 0 auto;
}

.checkout-wrapper {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 30px;
    margin-top: 40px;
}

.checkout-form, .order-summary {
    background: linear-gradient(145deg, #1e1e1e, #252525);
    border-radius: 15px;
    padding: 30px;
    border: 1px solid rgba(230, 57, 70, 0.2);
}

h1 {
    text-align: center;
    margin-bottom: 40px;
    font-size: 42px;
    background: linear-gradient(135deg, #e63946, #ff6b6b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.form-section h3 {
    color: #e63946;
    margin-bottom: 20px;
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #aaa;
    font-size: 14px;
    font-weight: 600;
}

input[type="text"],
input[type="email"],
input[type="tel"],
input[type="number"],
select {
    width: 100%;
    padding: 12px 15px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(230, 57, 70, 0.3);
    border-radius: 8px;
    color: #fff;
    font-size: 14px;
    transition: all 0.3s;
}

input:focus,
select:focus {
    outline: none;
    border-color: #e63946;
    box-shadow: 0 0 10px rgba(230, 57, 70, 0.3);
    background: rgba(255, 255, 255, 0.08);
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.payment-methods {
    display: grid;
    gap: 15px;
    margin-bottom: 20px;
}

.payment-option {
    padding: 15px;
    border: 2px solid rgba(230, 57, 70, 0.3);
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.3s;
    background: rgba(255, 255, 255, 0.02);
}

.payment-option:hover {
    border-color: #e63946;
    background: rgba(230, 57, 70, 0.1);
}

.payment-option input[type="radio"] {
    width: auto;
    margin-right: 10px;
}

.payment-option label {
    margin: 0;
    cursor: pointer;
    display: inline;
    color: #fff;
}

.payment-fields {
    display: none;
    margin-top: 20px;
    padding: 20px;
    background: rgba(230, 57, 70, 0.05);
    border-radius: 10px;
    border: 1px solid rgba(230, 57, 70, 0.2);
}

.payment-fields.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.order-summary h2 {
    color: #e63946;
    margin-bottom: 25px;
    font-size: 22px;
}

.summary-item {
    display: flex;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    color: #aaa;
}

.summary-item:last-of-type {
    border-bottom: none;
}

.summary-total {
    display: flex;
    justify-content: space-between;
    padding: 20px 0;
    font-size: 24px;
    font-weight: bold;
    color: #e63946;
    border-top: 2px solid #e63946;
    margin-top: 20px;
}

.btn {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, #e63946, #ff4757);
    color: #fff;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    margin-top: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(230, 57, 70, 0.4);
}

.btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.header {
    background: rgba(29, 29, 29, 0.95);
    backdrop-filter: blur(10px);
    padding: 15px 0;
    border-bottom: 2px solid #e63946;
    margin-bottom: 40px;
}

.header a {
    color: #fff;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: color 0.3s;
}

.header a:hover {
    color: #e63946;
}

@media (max-width: 768px) {
    .checkout-wrapper {
        grid-template-columns: 1fr;
    }
    
    .form-row {
        grid-template-columns: 1fr;
    }
    
    h1 {
        font-size: 32px;
    }
}
</style>
</head>
<body>

<div class="header">
    <div class="container">
        <a href="cart.php"><i class="fas fa-arrow-left"></i> Back to Cart</a>
    </div>
</div>

<div class="container">
    <h1><i class="fas fa-credit-card"></i> Checkout</h1>
    
    <div class="checkout-wrapper">
        <!-- Checkout Form -->
        <div class="checkout-form">
            <form method="POST">
                <!-- Billing Information -->
                <div class="form-section">
                    <h3><i class="fas fa-user"></i> Your Information</h3>
                    <div class="form-group">
                        <label>Full Name *</label>
                        <input type="text" name="name" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Email *</label>
                            <input type="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Phone *</label>
                            <input type="tel" name="phone" required>
                        </div>
                    </div>
                </div>

                <!-- Shipping Address -->
                <div class="form-section" style="margin-top: 30px;">
                    <h3><i class="fas fa-map-marker-alt"></i> Shipping Address</h3>
                    <div class="form-group">
                        <label>Address *</label>
                        <input type="text" name="address" placeholder="Street address" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>City *</label>
                            <input type="text" name="city" required>
                        </div>
                        <div class="form-group">
                            <label>Pincode *</label>
                            <input type="text" name="pincode" required>
                        </div>
                    </div>
                </div>

                <!-- Payment Method -->
                <div class="form-section" style="margin-top: 30px;">
                    <h3><i class="fas fa-wallet"></i> Payment Method</h3>
                    
                    <div class="payment-methods">
                        <div class="payment-option">
                            <input type="radio" id="cod" name="payment_method" value="cod" checked onchange="showPaymentFields()">
                            <label for="cod"><i class="fas fa-truck"></i> Cash on Delivery (COD)</label>
                        </div>
                        
                        <div class="payment-option">
                            <input type="radio" id="card" name="payment_method" value="card" onchange="showPaymentFields()">
                            <label for="card"><i class="fas fa-credit-card"></i> Debit/Credit Card</label>
                        </div>
                        
                        <div class="payment-option">
                            <input type="radio" id="upi" name="payment_method" value="upi" onchange="showPaymentFields()">
                            <label for="upi"><i class="fas fa-mobile-alt"></i> UPI</label>
                        </div>
                        
                        <div class="payment-option">
                            <input type="radio" id="wallet" name="payment_method" value="wallet" onchange="showPaymentFields()">
                            <label for="wallet"><i class="fas fa-wallet"></i> Digital Wallet</label>
                        </div>
                    </div>

                    <!-- Card Payment Fields -->
                    <div id="cardFields" class="payment-fields">
                        <div class="form-group">
                            <label>Card Number * (16 digits)</label>
                            <input type="text" name="card_number" placeholder="1234 5678 9012 3456" maxlength="16">
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Expiry Date * (MM/YY)</label>
                                <input type="text" name="card_expiry" placeholder="12/25">
                            </div>
                            <div class="form-group">
                                <label>CVV * (3 digits)</label>
                                <input type="text" name="card_cvv" placeholder="123" maxlength="3">
                            </div>
                        </div>
                    </div>

                    <!-- UPI Payment Fields -->
                    <div id="upiFields" class="payment-fields">
                        <div class="form-group">
                            <label>UPI ID * (e.g., yourname@bank)</label>
                            <input type="text" name="upi_id" placeholder="yourname@bank">
                        </div>
                    </div>

                    <!-- Wallet Payment Fields -->
                    <div id="walletFields" class="payment-fields">
                        <div class="form-group">
                            <label>Wallet Number/ID *</label>
                            <input type="text" name="wallet_id" placeholder="Your wallet ID">
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn"><i class="fas fa-check-circle"></i> Complete Payment</button>
            </form>
        </div>

        <!-- Order Summary -->
        <div class="order-summary">
            <h2>Order Summary</h2>
            <?php
            $item_count = 0;
            foreach($cart_items as $pid => $qty){
                $res = mysqli_query($conn,"SELECT name, price FROM products WHERE id=$pid");
                $prod = mysqli_fetch_assoc($res);
                $subtotal = $prod['price'] * $qty;
                $item_count += $qty;
            ?>
                <div class="summary-item">
                    <span><?php echo htmlentities($prod['name']); ?> x<?php echo $qty; ?></span>
                    <span>₹<?php echo number_format($subtotal, 2); ?></span>
                </div>
            <?php } ?>
            
            <div class="summary-item" style="padding-top: 20px; padding-bottom: 0;">
                <span>Subtotal</span>
                <span>₹<?php echo number_format($total_amount, 2); ?></span>
            </div>
            <div class="summary-item">
                <span>Shipping</span>
                <span>FREE</span>
            </div>
            <div class="summary-item">
                <span>Tax</span>
                <span>Included</span>
            </div>
            
            <div class="summary-total">
                <span>Total</span>
                <span>₹<?php echo number_format($total_amount, 2); ?></span>
            </div>
        </div>
    </div>
</div>

<script>
function showPaymentFields(){
    var method = document.querySelector('input[name="payment_method"]:checked').value;
    document.getElementById('cardFields').classList.remove('active');
    document.getElementById('upiFields').classList.remove('active');
    document.getElementById('walletFields').classList.remove('active');
    
    if(method === 'card') document.getElementById('cardFields').classList.add('active');
    else if(method === 'upi') document.getElementById('upiFields').classList.add('active');
    else if(method === 'wallet') document.getElementById('walletFields').classList.add('active');
}
</script>

</body>
</html>