<?php
session_start();
$conn = mysqli_connect("localhost","root","","geekboz_db");
if(!$conn) die("DB Error");

$category = isset($_GET['cat'])? mysqli_real_escape_string($conn,$_GET['cat']):'';
$products = mysqli_query($conn,"SELECT * FROM products WHERE category='$category' AND status='active'");

if(isset($_POST['add_to_cart'])){
    $product_id = intval($_POST['product_id']);
    if(!isset($_SESSION['cart'])) $_SESSION['cart']=array();
    if(isset($_SESSION['cart'][$product_id])) $_SESSION['cart'][$product_id] +=1;
    else $_SESSION['cart'][$product_id]=1;
    header("Location: category.php?cat=".$category);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo htmlentities($category); ?> - GeekBoz</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;}
.container{width:90%;margin:20px auto;}
.products-grid{display:flex;flex-wrap:wrap;gap:20px;}
.product-card{background:#fff;padding:15px;border-radius:10px;width:250px;text-align:center;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
.product-card img{width:100%;border-radius:10px;}
button{padding:10px 15px;background:#e63946;color:#fff;border:none;border-radius:5px;cursor:pointer;}
button:hover{background:#d62828;}
</style>
</head>
<body>
<div class="container">
<h1><?php echo htmlentities($category); ?></h1>
<div class="products-grid">
<?php while($row=mysqli_fetch_assoc($products)): ?>
<div class="product-card">
<img src="<?php echo $row['image']; ?>" alt="<?php echo htmlentities($row['name']); ?>">
<h3><?php echo htmlentities($row['name']); ?></h3>
<p>₹<?php echo number_format($row['price'],2); ?></p>
<form method="post">
<input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
<button type="submit" name="add_to_cart">Add to Cart</button>
</form>
</div>
<?php endwhile; ?>
</div>
</div>
</body>
</html>
