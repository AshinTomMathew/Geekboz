<?php
session_start();

// Initialize chat history
if(!isset($_SESSION['chat_history'])){
    $_SESSION['chat_history'] = array();
}

// Handle new message from user
if(isset($_POST['message'])){
    $msg = trim($_POST['message']);
    if($msg != ''){
        $_SESSION['chat_history'][] = array('sender'=>'user','message'=>$msg);

        // Bot reply logic (simple for now)
        $bot_msg = '';
        if(stripos($msg,'price')!==false){
            $bot_msg = "You can check product prices in our deals section!";
        } elseif(stripos($msg,'support')!==false){
            $bot_msg = "Our support is available 24/7. You can call or email us.";
        } else {
            $bot_msg = "Thanks for your message: \"$msg\". How can I assist you with GeekBoz?";
        }

        $_SESSION['chat_history'][] = array('sender'=>'bot','message'=>$bot_msg);
    }
    echo json_encode($_SESSION['chat_history']);
    exit;
}

// Return all messages if GET
echo json_encode($_SESSION['chat_history']);
?>
