<?php
session_start();
$conn = mysqli_connect("localhost","root","","geekboz_db");
if(!$conn){ die("DB failed: " . mysqli_connect_error()); }

// Handle Remove Item
if(isset($_GET['remove'])){
    $remove_id = intval($_GET['remove']);
    if(isset($_SESSION['cart'][$remove_id])){
        unset($_SESSION['cart'][$remove_id]);
    }
    header("Location: cart.php");
    exit;
}

$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : array();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cart - GeekBoz</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
    color: #fff;
    min-height: 100vh;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 40px 20px;
}

/* Header */
.page-header {
    background: rgba(29, 29, 29, 0.95);
    backdrop-filter: blur(10px);
    padding: 20px 0;
    margin-bottom: 40px;
    border-bottom: 2px solid #e63946;
    box-shadow: 0 4px 20px rgba(230, 57, 70, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
}

.logo {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    transition: transform 0.3s;
    text-decoration: none;
    color: #fff;
}

.logo:hover {
    transform: scale(1.05);
}

.logo-icon {
    background: linear-gradient(135deg, #e63946, #ff6b6b);
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    box-shadow: 0 4px 15px rgba(230, 57, 70, 0.4);
}

.logo-domain {
    color: #e63946;
}

.back-btn {
    padding: 12px 24px;
    background: rgba(230, 57, 70, 0.1);
    border: 1px solid #e63946;
    color: #fff;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
}

.back-btn:hover {
    background: #e63946;
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(230, 57, 70, 0.4);
}

/* Cart Title */
.cart-title {
    text-align: center;
    margin-bottom: 40px;
    position: relative;
}

.cart-title h1 {
    font-size: 48px;
    background: linear-gradient(135deg, #e63946, #ff6b6b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    display: inline-block;
    animation: fadeInDown 0.6s ease;
}

.cart-title p {
    color: #aaa;
    margin-top: 10px;
    font-size: 16px;
}

@keyframes fadeInDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Empty Cart */
.empty-cart {
    text-align: center;
    padding: 80px 20px;
    background: linear-gradient(145deg, #1e1e1e, #252525);
    border-radius: 20px;
    border: 1px solid rgba(230, 57, 70, 0.2);
    animation: fadeIn 0.6s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

.empty-cart-icon {
    font-size: 80px;
    color: #e63946;
    margin-bottom: 20px;
    opacity: 0.5;
}

.empty-cart h2 {
    font-size: 32px;
    margin-bottom: 15px;
    color: #fff;
}

.empty-cart p {
    font-size: 18px;
    color: #aaa;
    margin-bottom: 30px;
}

/* Cart Table */
.cart-wrapper {
    background: linear-gradient(145deg, #1e1e1e, #252525);
    border-radius: 20px;
    padding: 30px;
    border: 1px solid rgba(230, 57, 70, 0.2);
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
    animation: slideUp 0.6s ease;
    overflow-x: auto;
}

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.cart-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 15px;
    margin-bottom: 20px;
}

.cart-table thead tr {
    background: rgba(230, 57, 70, 0.1);
}

.cart-table th {
    padding: 18px;
    text-align: left;
    font-weight: 600;
    color: #e63946;
    text-transform: uppercase;
    font-size: 14px;
    letter-spacing: 1px;
    border: none;
}

.cart-table tbody tr {
    background: rgba(255, 255, 255, 0.05);
    transition: all 0.3s;
    border-radius: 10px;
}

.cart-table tbody tr:hover {
    background: rgba(230, 57, 70, 0.1);
    transform: translateX(5px);
    box-shadow: 0 5px 15px rgba(230, 57, 70, 0.2);
}

.cart-table td {
    padding: 20px 18px;
    border: none;
    vertical-align: middle;
}

.cart-table tbody tr td:first-child {
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
}

.cart-table tbody tr td:last-child {
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
}

.product-name {
    font-weight: 600;
    color: #fff;
    font-size: 16px;
}

.product-price {
    color: #e63946;
    font-weight: bold;
    font-size: 18px;
}

.product-qty {
    background: rgba(230, 57, 70, 0.2);
    padding: 8px 16px;
    border-radius: 20px;
    display: inline-block;
    font-weight: bold;
    color: #fff;
}

/* Cart Total */
.cart-total-row {
    background: linear-gradient(135deg, rgba(230, 57, 70, 0.2), rgba(255, 107, 107, 0.2)) !important;
    border: 2px solid #e63946 !important;
}

.cart-total-row td {
    font-size: 20px;
    font-weight: bold;
    padding: 25px 18px !important;
}

.total-label {
    color: #fff;
}

.total-amount {
    color: #e63946;
    font-size: 28px;
}

/* Buttons */
.btn {
    padding: 14px 32px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-size: 16px;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(230, 57, 70, 0.4);
}

.btn-primary {
    background: linear-gradient(135deg, #e63946, #ff4757);
    color: #fff;
    border: 2px solid transparent;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #ff4757, #e63946);
}

.remove-btn {
    background: rgba(230, 57, 70, 0.2);
    color: #e63946;
    border: 1px solid #e63946;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.remove-btn:hover {
    background: #e63946;
    color: #fff;
    transform: scale(1.05);
}

.cart-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
    margin-top: 30px;
    padding-top: 30px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.continue-shopping {
    color: #aaa;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: color 0.3s;
}

.continue-shopping:hover {
    color: #e63946;
}

/* Responsive */
@media (max-width: 768px) {
    .cart-title h1 {
        font-size: 36px;
    }
    
    .cart-wrapper {
        padding: 20px 10px;
    }
    
    .cart-table {
        font-size: 14px;
    }
    
    .cart-table th,
    .cart-table td {
        padding: 12px 8px;
    }
    
    .cart-actions {
        flex-direction: column;
        align-items: stretch;
    }
    
    .btn {
        justify-content: center;
        width: 100%;
    }
}

/* Scrollbar */
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}

::-webkit-scrollbar-track {
    background: #1a1a1a;
}

::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #e63946, #ff4757);
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #ff4757, #e63946);
}
</style>
</head>
<body>

<!-- Header -->
<div class="page-header">
    <div class="container">
        <div class="header-content">
            <a href="index.php" class="logo">
                <div class="logo-icon">G</div>
                <span>GeekBoz<span class="logo-domain">.in</span></span>
            </a>
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Continue Shopping
            </a>
        </div>
    </div>
</div>

<div class="container">
    <!-- Cart Title -->
    <div class="cart-title">
        <h1><i class="fas fa-shopping-cart"></i> Your Cart</h1>
        <p>Review your items before checkout</p>
    </div>

    <?php if(empty($cart_items)): ?>
        <!-- Empty Cart -->
        <div class="empty-cart">
            <div class="empty-cart-icon">
                <i class="fas fa-shopping-cart"></i>
            </div>
            <h2>Your cart is empty!</h2>
            <p>Start adding some awesome gaming gear to your cart</p>
            <a href="index.php" class="btn btn-primary">
                <i class="fas fa-store"></i> Start Shopping
            </a>
        </div>
    <?php else: ?>
        <!-- Cart Table -->
        <div class="cart-wrapper">
            <table class="cart-table">
                <thead>
                    <tr>
                        <th><i class="fas fa-box"></i> Product</th>
                        <th><i class="fas fa-tag"></i> Price</th>
                        <th><i class="fas fa-sort-numeric-up"></i> Quantity</th>
                        <th><i class="fas fa-calculator"></i> Total</th>
                        <th><i class="fas fa-cog"></i> Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total_price = 0;
                    foreach($cart_items as $pid => $qty):
                        $res = mysqli_query($conn,"SELECT * FROM products WHERE id=$pid");
                        $prod = mysqli_fetch_assoc($res);
                        $subtotal = $prod['price'] * $qty;
                        $total_price += $subtotal;
                    ?>
                    <tr>
                        <td class="product-name"><?php echo htmlentities($prod['name']); ?></td>
                        <td class="product-price">₹<?php echo number_format($prod['price'],2); ?></td>
                        <td><span class="product-qty"><?php echo $qty; ?></span></td>
                        <td class="product-price">₹<?php echo number_format($subtotal,2); ?></td>
                        <td>
                            <a href="cart.php?remove=<?php echo $pid; ?>" class="remove-btn">
                                <i class="fas fa-trash-alt"></i> Remove
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Total Row -->
                    <tr class="cart-total-row">
                        <td colspan="3" class="total-label">
                            <i class="fas fa-receipt"></i> Grand Total
                        </td>
                        <td colspan="2" class="total-amount">
                            ₹<?php echo number_format($total_price,2); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            
            <!-- Cart Actions -->
            <div class="cart-actions">
                <a href="index.php" class="continue-shopping">
                    <i class="fas fa-arrow-left"></i> Continue Shopping
                </a>
                <a href="checkout.php" class="btn btn-primary">
                    <i class="fas fa-credit-card"></i> Proceed to Checkout
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

</body>
</html>