<?php
session_start();
require_once 'db.php';
$user_id = 1; // Replace with session user
$stmt = $conn->prepare("SELECT SUM(quantity) as count FROM cart WHERE user_id=?");
$stmt->execute([$user_id]);
$count = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
echo json_encode(['count'=>$count]);
?>
