<?php
session_start();

// Database connection
$conn = mysqli_connect("localhost","root","","geekboz_db");
if(!$conn){
    die("Database connection failed: " . mysqli_connect_error());
}

// Handle Add to Cart
if(isset($_POST['add_to_cart'])){
    $product_id = intval($_POST['product_id']);
    if(!isset($_SESSION['cart'])){
        $_SESSION['cart'] = array();
    }
    if(isset($_SESSION['cart'][$product_id])){
        $_SESSION['cart'][$product_id] += 1;
    } else {
        $_SESSION['cart'][$product_id] = 1;
    }
    header("Location: index.php");
    exit;
}

// Fetch featured products
$featured_products_query = "SELECT * FROM products WHERE featured=1 AND status='active' ORDER BY created_at DESC";
$featured_products = mysqli_query($conn, $featured_products_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GeekBoz - Premium Gaming Gear</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #0a0a0a;
    color: #fff;
    overflow-x: hidden;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 0 auto;
}

/* Header Styles */
.header {
    background: rgba(29, 29, 29, 0.95);
    backdrop-filter: blur(10px);
    padding: 15px 0;
    position: sticky;
    top: 0;
    z-index: 999;
    border-bottom: 2px solid #e63946;
    box-shadow: 0 4px 20px rgba(230, 57, 70, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
}

.logo {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    transition: transform 0.3s;
}

.logo:hover {
    transform: scale(1.05);
}

.logo-icon {
    background: linear-gradient(135deg, #e63946, #ff6b6b);
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    box-shadow: 0 4px 15px rgba(230, 57, 70, 0.4);
}

.logo-domain {
    color: #e63946;
}

.header-actions {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.btn {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(230, 57, 70, 0.4);
}

.btn-primary {
    background: linear-gradient(135deg, #e63946, #ff4757);
    color: #fff;
    border: 2px solid transparent;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #ff4757, #e63946);
}

.btn-outline {
    background: transparent;
    border: 2px solid #e63946;
    color: #e63946;
}

.btn-outline:hover {
    background: #e63946;
    color: #fff;
}

.header-actions .btn {
    background: rgba(230, 57, 70, 0.1);
    border: 1px solid #e63946;
    color: #fff;
}

.header-actions .btn:hover {
    background: #e63946;
}

/* Hero Section */
.hero {
    background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), 
                url('https://images.unsplash.com/photo-1733945761533-727f49908d70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080') no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    color: #fff;
    padding: 120px 0;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at 50% 50%, rgba(230, 57, 70, 0.2), transparent 70%);
    animation: pulse 4s ease-in-out infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 0.5; }
    50% { opacity: 1; }
}

.hero h1 {
    font-size: 56px;
    font-weight: 900;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
    text-shadow: 0 4px 20px rgba(0, 0, 0, 0.8);
    animation: fadeInUp 1s ease;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.highlight {
    background: linear-gradient(135deg, #e63946, #ff6b6b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.hero p {
    font-size: 20px;
    margin-bottom: 30px;
    max-width: 700px;
    margin-left: auto;
    margin-right: auto;
    position: relative;
    z-index: 1;
    animation: fadeInUp 1s ease 0.2s both;
    line-height: 1.6;
}

.hero .btn {
    margin: 10px;
    position: relative;
    z-index: 1;
    animation: fadeInUp 1s ease 0.4s both;
}

/* Featured Products Section */
.featured-products {
    padding: 80px 0;
    background: linear-gradient(180deg, #0a0a0a 0%, #1a1a1a 100%);
}

.featured-products h2 {
    text-align: center;
    font-size: 42px;
    margin-bottom: 50px;
    position: relative;
    display: inline-block;
    left: 50%;
    transform: translateX(-50%);
}

.featured-products h2::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 100px;
    height: 4px;
    background: linear-gradient(90deg, #e63946, #ff6b6b);
    border-radius: 2px;
}

.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 30px;
    margin-top: 20px;
}

.product-card {
    background: linear-gradient(145deg, #1e1e1e, #252525);
    padding: 20px;
    border-radius: 15px;
    text-align: center;
    transition: all 0.4s;
    border: 1px solid rgba(230, 57, 70, 0.2);
    position: relative;
    overflow: hidden;
}

.product-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(230, 57, 70, 0.1), transparent);
    transition: left 0.5s;
}

.product-card:hover::before {
    left: 100%;
}

.product-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 40px rgba(230, 57, 70, 0.4);
    border-color: #e63946;
}

.product-card img {
    width: 100%;
    height: 220px;
    object-fit: cover;
    border-radius: 10px;
    margin-bottom: 15px;
    transition: transform 0.4s;
}

.product-card:hover img {
    transform: scale(1.08);
}

.product-card h3 {
    font-size: 18px;
    margin: 15px 0 10px;
    color: #fff;
    min-height: 50px;
}

.product-card p {
    font-size: 24px;
    font-weight: bold;
    color: #e63946;
    margin: 10px 0;
}

.product-card form {
    margin-top: 15px;
}

/* Footer */
.footer {
    background: #1d1d1d;
    color: #fff;
    padding: 50px 0 20px;
    border-top: 3px solid #e63946;
}

.footer-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 40px;
    margin-bottom: 30px;
}

.footer-section h3 {
    color: #e63946;
    margin-bottom: 20px;
    font-size: 20px;
}

.footer-section ul {
    list-style: none;
}

.footer-section ul li {
    margin-bottom: 10px;
}

.footer-section a {
    color: #ccc;
    text-decoration: none;
    transition: color 0.3s;
}

.footer-section a:hover {
    color: #e63946;
}

.footer-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 15px;
}

.footer-section p {
    color: #aaa;
    line-height: 1.8;
}

.footer-bottom {
    text-align: center;
    padding-top: 20px;
    border-top: 1px solid #444;
    color: #888;
}

/* Chat Widget */
.chat-widget {
    position: fixed;
    bottom: 90px;
    right: 20px;
    width: 320px;
    height: 450px;
    background: #fff;
    border-radius: 15px;
    display: none;
    flex-direction: column;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
    overflow: hidden;
    z-index: 1000;
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from {
        transform: translateY(20px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.chat-header {
    background: linear-gradient(135deg, #e63946, #ff4757);
    color: #fff;
    padding: 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: bold;
}

.chat-header button {
    background: none;
    border: none;
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    transition: transform 0.3s;
}

.chat-header button:hover {
    transform: rotate(90deg);
}

.chat-body {
    flex: 1;
    overflow-y: auto;
    padding: 15px;
    background: #f8f8f8;
    display: flex;
    flex-direction: column;
}

#chatMessages {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.user-message, .bot-message {
    padding: 10px 15px;
    border-radius: 15px;
    max-width: 80%;
    word-wrap: break-word;
    animation: messageSlide 0.3s ease;
}

@keyframes messageSlide {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.user-message {
    background: linear-gradient(135deg, #e63946, #ff4757);
    color: #fff;
    align-self: flex-end;
    border-bottom-right-radius: 5px;
}

.bot-message {
    background: #fff;
    color: #333;
    align-self: flex-start;
    border-bottom-left-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.chat-input {
    display: flex;
    border-top: 1px solid #ddd;
    background: #fff;
}

.chat-input input {
    flex: 1;
    padding: 12px;
    border: none;
    outline: none;
    font-size: 14px;
}

.chat-input button {
    background: linear-gradient(135deg, #e63946, #ff4757);
    color: #fff;
    border: none;
    padding: 0 20px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s;
}

.chat-input button:hover {
    background: linear-gradient(135deg, #ff4757, #e63946);
}

.chat-toggle {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: linear-gradient(135deg, #e63946, #ff4757);
    color: #fff;
    border: none;
    border-radius: 50%;
    width: 65px;
    height: 65px;
    font-size: 28px;
    cursor: pointer;
    z-index: 1000;
    box-shadow: 0 5px 25px rgba(230, 57, 70, 0.5);
    transition: all 0.3s;
}

.chat-toggle:hover {
    transform: scale(1.1);
    box-shadow: 0 8px 30px rgba(230, 57, 70, 0.7);
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero h1 {
        font-size: 36px;
    }
    
    .hero p {
        font-size: 16px;
    }
    
    .featured-products h2 {
        font-size: 32px;
    }
    
    .products-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }
    
    .chat-widget {
        width: 90%;
        right: 5%;
    }
}

/* Scrollbar Styling */
::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: #1a1a1a;
}

::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #e63946, #ff4757);
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #ff4757, #e63946);
}
</style>
</head>
<body>

<!-- Header -->
<header class="header">
<div class="container header-content">
    <div class="logo" onclick="window.location='index.php';">
        <div class="logo-icon">G</div>
        <span>GeekBoz<span class="logo-domain">.in</span></span>
    </div>
    <div class="header-actions">
        <?php if(isset($_SESSION['user_name'])): ?>
            <button onclick="window.location='users.php?logout=1'" class="btn"><i class="fas fa-sign-out-alt"></i> Logout (<?php echo htmlentities($_SESSION['user_name']); ?>)</button>
        <?php else: ?>
            <button onclick="window.location='users.php'" class="btn"><i class="fas fa-user"></i> Account</button>
        <?php endif; ?>
        <button onclick="window.location='cart.php'" class="btn"><i class="fas fa-shopping-cart"></i> Cart (<?php echo isset($_SESSION['cart'])?array_sum($_SESSION['cart']):0; ?>)</button>
    </div>
</div>
</header>

<!-- Hero Section -->
<section class="hero">
<div class="container">
    <h1>Level Up Your <span class="highlight">Gaming</span> Experience</h1>
    <p>Premium gaming gear, components, and custom PCs with transparent pricing, COD availability, and 24/7 support.</p>
    <button class="btn btn-primary" onclick="window.location='category.php?cat=Deals'"><i class="fas fa-fire"></i> Shop Now</button>
    <button class="btn btn-outline" onclick="window.location='category.php?cat=Custom PCs'"><i class="fas fa-desktop"></i> Build Custom PC</button>
</div>
</section>

<!-- Featured Products -->
<section class="featured-products">
<div class="container">
    <h2>Featured Products</h2>
    <div class="products-grid">
    <?php while($row = mysqli_fetch_assoc($featured_products)): ?>
        <div class="product-card">
            <img src="<?php echo htmlentities($row['image']); ?>" alt="<?php echo htmlentities($row['name']); ?>">
            <h3><?php echo htmlentities($row['name']); ?></h3>
            <p>₹<?php echo number_format($row['price'],2); ?></p>
            <form method="post" action="">
                <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                <button type="submit" name="add_to_cart" class="btn btn-primary"><i class="fas fa-cart-plus"></i> Add to Cart</button>
            </form>
        </div>
    <?php endwhile; ?>
    </div>
</div>
</section>

<!-- Footer -->
<footer class="footer">
<div class="container">
    <div class="footer-content">
        <div class="footer-section">
            <div class="footer-logo">
                <div class="logo-icon">G</div>
                <span>GeekBoz<span class="logo-domain">.in</span></span>
            </div>
            <p>Your trusted partner for premium gaming gear with transparent pricing, 24/7 support, and COD availability across India.</p>
        </div>
        <div class="footer-section">
            <h3>Shop</h3>
            <ul>
                <li><a href="category.php?cat=Gaming Laptops"><i class="fas fa-laptop"></i> Gaming Laptops</a></li>
                <li><a href="category.php?cat=Components"><i class="fas fa-microchip"></i> Components</a></li>
                <li><a href="category.php?cat=Peripherals"><i class="fas fa-keyboard"></i> Peripherals</a></li>
                <li><a href="category.php?cat=Custom PCs"><i class="fas fa-desktop"></i> Custom PC Builder</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Support</h3>
            <ul>
                <li><a href="support.php"><i class="fas fa-headset"></i> Help Center</a></li>
                <li><a href="#"><i class="fas fa-truck"></i> Order Tracking</a></li>
                <li><a href="#"><i class="fas fa-undo"></i> Return Policy</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contact Us</h3>
            <p><i class="fas fa-phone"></i> +91 9876543210</p>
            <p><i class="fas fa-envelope"></i> support@geekboz.in</p>
        </div>
    </div>
    <div class="footer-bottom">
        &copy; 2025 GeekBoz.in. All rights reserved.
    </div>
</div>
</footer>

<!-- Chat Widget -->
<div id="chatWidget" class="chat-widget">
    <div class="chat-header">
        <span><i class="fas fa-headset"></i> GeekBoz Support</span>
        <button onclick="toggleChat()">✖</button>
    </div>
    <div class="chat-body">
        <div id="chatMessages">
            <div class="bot-message">Hi! I'm your GeekBoz assistant. How can I help you today? 🎮</div>
        </div>
    </div>
    <div class="chat-input">
        <input type="text" id="chatInput" placeholder="Type your message..." onkeypress="if(event.key==='Enter') sendMessage()">
        <button onclick="sendMessage()"><i class="fas fa-paper-plane"></i></button>
    </div>
</div>
<button class="chat-toggle" onclick="toggleChat()">💬</button>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
var chatOpen = false;
function toggleChat(){
    chatOpen = !chatOpen;
    if(chatOpen){
        $('#chatWidget').fadeIn().css('display', 'flex');
        $('.chat-toggle').fadeOut();
    } else {
        $('#chatWidget').fadeOut();
        $('.chat-toggle').fadeIn();
    }
}
function sendMessage(){
    var msg = $('#chatInput').val().trim();
    if(msg=='') return;
    $('#chatInput').val('');
    $('#chatMessages').append('<div class="user-message">'+msg+'</div>');
    setTimeout(function(){
        $('#chatMessages').append('<div class="bot-message">Thanks for your message! Our support team will contact you soon. 😊</div>');
        $('#chatMessages').scrollTop($('#chatMessages')[0].scrollHeight);
    }, 500);
    $('#chatMessages').scrollTop($('#chatMessages')[0].scrollHeight);
}
</script>

</body>
</html>