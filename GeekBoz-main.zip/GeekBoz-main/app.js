function addToCart(productId){
    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=add&product_id=' + productId
    })
    .then(res => res.text())
    .then(data => {
        if(data === "added"){
            alert("Product added to cart!");
            updateCartCount();
        }
    });
}

function updateCartCount(){
    fetch('cart_count.php')
    .then(res => res.json())
    .then(data => {
        document.getElementById('cartCount').innerText = data.count;
    });
}

// Run on page load
updateCartCount();
