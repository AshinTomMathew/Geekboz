<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - GeekBoz</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="auth-container">
        <h1>Login</h1>
        <?php
        if(isset($_SESSION['error'])){ echo '<p class="error">'.$_SESSION['error'].'</p>'; unset($_SESSION['error']); }
        if(isset($_SESSION['success'])){ echo '<p class="success">'.$_SESSION['success'].'</p>'; unset($_SESSION['success']); }
        ?>
        <form action="users.php" method="POST">
            <input type="hidden" name="action" value="login">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>
